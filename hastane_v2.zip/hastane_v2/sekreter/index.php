<?php
require_once '../includes/db.php';
require_once 'layout.php';
$toplam_hasta    = sqlsrv_fetch_array(sqlsrv_query($conn,"SELECT COUNT(*) as c FROM Hastalar"))['c'];
$bugun_randevu   = sqlsrv_fetch_array(sqlsrv_query($conn,"SELECT COUNT(*) as c FROM Randevular WHERE CAST(RandevuTarihi AS DATE)=CAST(GETDATE() AS DATE)"))['c'];
$bekleyen_tahlil = sqlsrv_fetch_array(sqlsrv_query($conn,"SELECT COUNT(*) as c FROM Tahliller WHERE Durum='Bekliyor'"))['c'];
$randevular = sqlsrv_query($conn,"
    SELECT R.RandevuTarihi, R.Durum, H.Ad, H.Soyad, K.Ad AS DAd, K.Soyad AS DSoyad, B.BolumAdi
    FROM Randevular R
    JOIN Hastalar H ON R.HastaID=H.HastaID
    JOIN Kullanicilar K ON R.DoktorID=K.KullaniciID
    JOIN Bolumler B ON R.BolumID=B.BolumID
    WHERE CAST(R.RandevuTarihi AS DATE)=CAST(GETDATE() AS DATE)
    ORDER BY R.RandevuTarihi ASC");
?>
<div class="ust-bar">
    <div class="ust-bar-baslik">Bugünkü Randevular</div>
    <div class="ust-bar-sag"><span class="etiket etiket-mavi"><?= date('d.m.Y') ?></span></div>
</div>
<div class="icerik">
    <div class="stat-grid stat-grid-3">
        <div class="stat-kart mavi"><div class="stat-etiket">Toplam Hasta</div><div class="stat-deger"><?= number_format($toplam_hasta) ?></div></div>
        <div class="stat-kart yesil"><div class="stat-etiket">Bugün Randevu</div><div class="stat-deger"><?= $bugun_randevu ?></div></div>
        <div class="stat-kart sari"><div class="stat-etiket">Bekleyen Tahlil</div><div class="stat-deger"><?= $bekleyen_tahlil ?></div></div>
    </div>
    <div class="panel">
        <div class="panel-baslik"><h3>Bugünkü Randevular</h3><a href="/hastane_v2/sekreter/randevu_olustur.php">+ Randevu Ekle</a></div>
        <div class="tablo-sarici"><table class="tablo">
            <thead><tr><th>Saat</th><th>Hasta Ad</th><th>Hasta Soyad</th><th>Doktor</th><th>Bölüm</th><th>Durum</th></tr></thead>
            <tbody>
            <?php $sayi=0; while($r=sqlsrv_fetch_array($randevular,SQLSRV_FETCH_ASSOC)): $sayi++;
                $renk=match($r['Durum']){'Tamamlandı'=>'etiket-yesil','İptal'=>'etiket-kirmizi',default=>'etiket-sari'}; ?>
            <tr>
                <td class="soluk"><?= saatFormat($r['RandevuTarihi']) ?></td>
                <td><?= temizle($r['Ad']) ?></td>
                <td><?= temizle($r['Soyad']) ?></td>
                <td>Dr. <?= temizle($r['DAd'].' '.$r['DSoyad']) ?></td>
                <td class="soluk"><?= temizle($r['BolumAdi']) ?></td>
                <td><span class="etiket <?= $renk ?>"><?= temizle($r['Durum']) ?></span></td>
            </tr>
            <?php endwhile; if($sayi===0): ?>
            <tr><td colspan="6" style="text-align:center;color:#64748b;padding:20px;">Bugün randevu yok.</td></tr>
            <?php endif; ?>
            </tbody>
        </table></div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>