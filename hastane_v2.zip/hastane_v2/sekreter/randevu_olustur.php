<?php
if (isset($_GET['dolu_saatler'])) {
    require_once '../includes/db.php';
    $d_id  = (int)$_GET['doktor_id'];
    $g     = $_GET['gun'] ?? '';
    $sorgu = sqlsrv_query($conn,
        "SELECT CONVERT(VARCHAR(5), RandevuTarihi, 108) as saat
         FROM Randevular
         WHERE DoktorID=? AND CAST(RandevuTarihi AS DATE)=?",
        [$d_id, $g]
    );
    $dolu = [];
    while ($r = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC)) {
        $dolu[] = $r['saat'];
    }
    header('Content-Type: application/json');
    echo json_encode($dolu);
    exit;
}


require_once '../includes/db.php';
require_once 'layout.php';

$mesaj        = null;
$hatalar      = [];
$aranan_hasta = null;


if (isset($_GET['tc_ara'])) {
    $aramaGirdisi = trim($_GET['tc_ara']);
    if (!empty($aramaGirdisi)) {
        
        if (ctype_digit($aramaGirdisi) && strlen($aramaGirdisi) < 11) {
            $sorgu = sqlsrv_query($conn, "SELECT * FROM Hastalar WHERE HastaID=?", [(int)$aramaGirdisi]);
        } else {
            
            $sorgu = sqlsrv_query($conn, "SELECT * FROM Hastalar WHERE TCKimlik=?", [$aramaGirdisi]);
        }
        $aranan_hasta = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);
        if (!$aranan_hasta) {
            $mesaj = ['tip' => 'hata', 'metin' => "\"$aramaGirdisi\" ile kayıtlı hasta bulunamadı."];
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['randevu_kaydet'])) {
    $hasta_id  = (int)$_POST['hasta_id'];
    $doktor_id = (int)$_POST['doktor_id'];
    $bolum_id  = (int)$_POST['bolum_id'];
    $tarih     = trim($_POST['randevu_tarihi'] ?? '');

    if (!$hasta_id)    $hatalar['hasta']  = 'Hasta seçilmedi.';
    if (!$doktor_id)   $hatalar['doktor'] = 'Doktor seçilmedi.';
    if (!$bolum_id)    $hatalar['bolum']  = 'Bölüm seçilmedi.';
    if (empty($tarih)) $hatalar['tarih']  = 'Gün ve saat seçilmedi.';

    if (empty($hatalar)) {
        $sorgu = sqlsrv_query($conn,
            "INSERT INTO Randevular (HastaID, DoktorID, BolumID, RandevuTarihi, Durum)
             VALUES (?, ?, ?, ?, 'Bekliyor')",
            [$hasta_id, $doktor_id, $bolum_id, $tarih]
        );
        $mesaj = $sorgu
            ? ['tip' => 'basari', 'metin' => 'Randevu başarıyla oluşturuldu.']
            : ['tip' => 'hata',   'metin' => 'Hata oluştu.'];
        if ($sorgu) { $_POST = []; $aranan_hasta = null; }
    } else {
        
        $sorgu = sqlsrv_query($conn, "SELECT * FROM Hastalar WHERE HastaID=?", [$hasta_id]);
        $aranan_hasta = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);
    }
}


$bolumler = sqlsrv_query($conn, "SELECT BolumID, BolumAdi FROM Bolumler ORDER BY BolumAdi");
$bolum_listesi = [];
while ($b = sqlsrv_fetch_array($bolumler, SQLSRV_FETCH_ASSOC)) {
    $bolum_listesi[] = $b;
}


$doktorlar = sqlsrv_query($conn,
    "SELECT KullaniciID, Ad, Soyad, BolumID FROM Kullanicilar
     WHERE Unvan='doktor' AND aktif=1 ORDER BY Ad"
);
$doktor_listesi = [];
while ($d = sqlsrv_fetch_array($doktorlar, SQLSRV_FETCH_ASSOC)) {
    $doktor_listesi[] = $d;
}

?>

<div class="ust-bar">
    <div class="ust-bar-baslik">Randevu Oluştur</div>
</div>

<div class="icerik">

    <?php if ($mesaj): ?>
        <div class="bildirim bildirim-<?= $mesaj['tip'] === 'basari' ? 'basari' : 'hata' ?>">
            <?= $mesaj['tip'] === 'basari' ? '✓' : '✗' ?>
            <?= temizle($mesaj['metin']) ?>
        </div>
    <?php endif; ?>


    <div class="panel" style="max-width:500px; margin-bottom:20px;">
        <div class="panel-baslik"><h3>Adım 1 — Hasta Ara (TC ile)</h3></div>
        <div class="panel-icerik">
            <form method="GET" action="" style="display:flex; gap:8px;">
                <input type="text" name="tc_ara"
                       placeholder="TC kimlik veya Hasta ID girin..."
                       value="<?= temizle($_GET['tc_ara'] ?? '') ?>"
                       maxlength="11"
                       style="flex:1; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:7px; padding:9px 12px; color:#f8fafc; font-family:'DM Sans',sans-serif; font-size:13px; outline:none;">
                <button type="submit" class="btn btn-mavi">Ara</button>
            </form>

            <?php if ($aranan_hasta): ?>
            <div style="margin-top:14px; padding:12px; background:rgba(16,185,129,0.08); border:1px solid rgba(16,185,129,0.2); border-radius:7px;">
                <div style="font-size:12px; color:#64748b; margin-bottom:4px;">Hasta Bulundu:</div>
                <div style="font-size:14px; color:#f8fafc;">
                    <strong>#<?= $aranan_hasta['HastaID'] ?> — <?= temizle($aranan_hasta['Ad'].' '.$aranan_hasta['Soyad']) ?></strong>
                    <span class="etiket etiket-kirmizi" style="margin-left:8px;"><?= temizle($aranan_hasta['KanGrubu'] ?? '') ?></span>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($aranan_hasta): ?>
    <div class="panel">
        <div class="panel-baslik"><h3>Adım 2 — Randevu Bilgileri</h3></div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <input type="hidden" name="hasta_id"       value="<?= $aranan_hasta['HastaID'] ?>">
                <input type="hidden" name="randevu_tarihi" id="randevu_tarihi">

                <div class="form-grid">

                    <div class="form-grup">
                        <label for="bolum_id">Bölüm *</label>
                        <select id="bolum_id" name="bolum_id" required
                                onchange="doktorFiltrele(this.value)"
                                class="<?= isset($hatalar['bolum']) ? 'hatali' : '' ?>">
                            <option value="">-- Bölüm Seç --</option>
                            <?php foreach ($bolum_listesi as $b): ?>
                            <option value="<?= $b['BolumID'] ?>"
                                <?= ($_POST['bolum_id'] ?? '') == $b['BolumID'] ? 'selected' : '' ?>>
                                <?= temizle($b['BolumAdi']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (isset($hatalar['bolum'])): ?>
                            <span class="form-hata"><?= $hatalar['bolum'] ?></span>
                        <?php endif; ?>
                    </div>


                    <div class="form-grup">
                        <label for="doktor_id">Doktor *</label>
                        <select id="doktor_id" name="doktor_id" required
                                onchange="saatleriGuncelle()"
                                class="<?= isset($hatalar['doktor']) ? 'hatali' : '' ?>">
                            <option value="">-- Önce bölüm seçin --</option>
                        </select>
                        <?php if (isset($hatalar['doktor'])): ?>
                            <span class="form-hata"><?= $hatalar['doktor'] ?></span>
                        <?php endif; ?>
                    </div>


                    <div class="form-grup">
                        <label for="randevu_gun">Gün *</label>
                        <select id="randevu_gun" name="randevu_gun" required
                                onchange="saatleriGuncelle()"
                                class="<?= isset($hatalar['tarih']) ? 'hatali' : '' ?>">
                            <option value="">-- Gün Seçin --</option>
                            <?php
                            $gunler_tr = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'];
                            for ($i = 0; $i < 7; $i++):
                                $timestamp = strtotime("+$i day");
                                $gun_no    = (int)date('w', $timestamp);
                                $tarih_str = date('Y-m-d', $timestamp);
                                $gosterim  = $gunler_tr[$gun_no] . ' ' . date('d.m.Y', $timestamp);
                                $secili    = ($_POST['randevu_gun'] ?? '') === $tarih_str ? 'selected' : '';
                            ?>
                            <option value="<?= $tarih_str ?>" <?= $secili ?>><?= $gosterim ?></option>
                            <?php endfor; ?>
                        </select>
                        <?php if (isset($hatalar['tarih'])): ?>
                            <span class="form-hata"><?= $hatalar['tarih'] ?></span>
                        <?php endif; ?>
                    </div>


                    <div class="form-grup">
                        <label for="randevu_saat">Saat *</label>
                        <select id="randevu_saat" name="randevu_saat" required>
                            <option value="">-- Önce gün seçin --</option>
                        </select>
                    </div>

                </div>

                <div class="form-aksiyonlar">
                    <button type="submit" name="randevu_kaydet" class="btn btn-mavi">+ Randevu Oluştur</button>
                </div>

            </form>
        </div>
    </div>
    <?php endif; ?>

</div>

<script>

var doktorlar    = <?= json_encode($doktor_listesi) ?>;
var seciliDoktor = <?= (int)($_POST['doktor_id'] ?? 0) ?>;

function doktorFiltrele(bolumId) {
    var select = document.getElementById('doktor_id');
    select.innerHTML = '<option value="">-- Doktor Seç --</option>';


    document.getElementById('randevu_saat').innerHTML = '<option value="">-- Önce gün seçin --</option>';
    document.getElementById('randevu_tarihi').value = '';

    doktorlar.forEach(function(d) {
        if (String(d.BolumID) === String(bolumId)) {
            var opt        = document.createElement('option');
            opt.value      = d.KullaniciID;
            opt.textContent = 'Dr. ' + d.Ad + ' ' + d.Soyad;
            if (d.KullaniciID == seciliDoktor) opt.selected = true;
            select.appendChild(opt);
        }
    });

    if (select.options.length === 1) {
        select.innerHTML = '<option value="">Bu bölümde doktor yok</option>';
    }
}


var tumSaatler = [
    '09:00','09:30',
    '10:00','10:30',
    '11:00','11:30',
    // 12:00-13:00 öğle arası yok
    '13:00','13:30',
    '14:00','14:30',
    '15:00','15:30',
    '16:00','16:30',
    '17:00'
];

function saatleriGuncelle() {
    var doktorId = document.getElementById('doktor_id').value;
    var gun      = document.getElementById('randevu_gun').value;
    var saatSel  = document.getElementById('randevu_saat');
    var hidden   = document.getElementById('randevu_tarihi');

    
    if (!doktorId || !gun) {
        saatSel.innerHTML = '<option value="">-- Önce doktor ve gün seçin --</option>';
        hidden.value = '';
        return;
    }

    saatSel.innerHTML = '<option value="">Yükleniyor...</option>';
    hidden.value = '';


    fetch('randevu_olustur.php?dolu_saatler=1&doktor_id=' + doktorId + '&gun=' + gun)
        .then(function(r) { return r.json(); })
        .then(function(doluSaatler) {
            saatSel.innerHTML = '<option value="">-- Saat Seçin --</option>';

            tumSaatler.forEach(function(saat) {
                if (doluSaatler.indexOf(saat) === -1) {
                    
                    var opt        = document.createElement('option');
                    opt.value      = saat;
                    opt.textContent = saat;
                    saatSel.appendChild(opt);
                }
            });

            if (saatSel.options.length === 1) {
                saatSel.innerHTML = '<option value="">Bu gün müsait saat yok</option>';
            }
        });
}


document.getElementById('randevu_saat').addEventListener('change', function() {
    var gun  = document.getElementById('randevu_gun').value;
    var saat = this.value;
    document.getElementById('randevu_tarihi').value = (gun && saat) ? gun + ' ' + saat + ':00' : '';
});


window.onload = function() {
    var bolumSel = document.getElementById('bolum_id');
    if (bolumSel && bolumSel.value) {
        doktorFiltrele(bolumSel.value);
    }
};
</script>

<?php require_once '../includes/footer.php'; ?>