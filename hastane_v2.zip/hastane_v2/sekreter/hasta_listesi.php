<?php
require_once '../includes/db.php';
require_once 'layout.php';

$hasta_id_detay = isset($_GET['hasta_id']) ? (int)$_GET['hasta_id'] : null;
$hasta_detay    = null;


if ($hasta_id_detay) {
    $sorgu = sqlsrv_query($conn, "SELECT * FROM Hastalar WHERE HastaID=?", [$hasta_id_detay]);
    $hasta_detay = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);
    if ($hasta_detay) {
        $tahliller  = sqlsrv_query($conn,
            "SELECT T.*, K.Ad+' '+K.Soyad as doktor_adi
             FROM Tahliller T JOIN Kullanicilar K ON T.DoktorID=K.KullaniciID
             WHERE T.HastaID=? ORDER BY T.IstekTarihi DESC", [$hasta_id_detay]);
        $randevular = sqlsrv_query($conn,
            "SELECT R.*, K.Ad+' '+K.Soyad as doktor_adi, B.BolumAdi
             FROM Randevular R
             JOIN Kullanicilar K ON R.DoktorID=K.KullaniciID
             JOIN Bolumler B ON R.BolumID=B.BolumID
             WHERE R.HastaID=? ORDER BY R.RandevuTarihi DESC", [$hasta_id_detay]);
    }
}


$arama    = trim($_GET['ara']      ?? '');
$cinsiyet = trim($_GET['cinsiyet'] ?? '');
$kan      = trim($_GET['kan']      ?? '');
$tel      = trim($_GET['tel']      ?? '');
$yas_min  = trim($_GET['yas_min']  ?? '');
$yas_max  = trim($_GET['yas_max']  ?? '');
$id_ara   = trim($_GET['id_ara']   ?? '');


$kosullar = [];
$params   = [];


if ($id_ara !== '') {
    $kosullar[] = "HastaID = ?";
    $params[]   = (int)$id_ara;
} else {
    
    if ($arama) {
        $kosullar[] = "(Ad LIKE ? OR Soyad LIKE ? OR TCKimlik LIKE ?)";
        $params = array_merge($params, ["%$arama%", "%$arama%", "%$arama%"]);
    }
    
    if ($cinsiyet) {
        $kosullar[] = "Cinsiyet = ?";
        $params[]   = $cinsiyet;
    }
    
    if ($kan) {
        $kosullar[] = "KanGrubu = ?";
        $params[]   = $kan;
    }
    
    if ($tel) {
        $kosullar[] = "Telefon LIKE ?";
        $params[]   = "%$tel%";
    }
    
    if ($yas_min !== '') {
        $kosullar[] = "DATEDIFF(YEAR, DogumTarihi, GETDATE()) >= ?";
        $params[]   = (int)$yas_min;
    }
    if ($yas_max !== '') {
        $kosullar[] = "DATEDIFF(YEAR, DogumTarihi, GETDATE()) <= ?";
        $params[]   = (int)$yas_max;
    }
}

$where    = $kosullar ? "WHERE " . implode(" AND ", $kosullar) : "";
$sql      = "SELECT *, DATEDIFF(YEAR, DogumTarihi, GETDATE()) AS yas FROM Hastalar $where ORDER BY KayitTarihi DESC";
$hastalar = sqlsrv_query($conn, $sql, $params ?: null);

$aramaVar = $arama || $cinsiyet || $kan || $tel || $yas_min !== '' || $yas_max !== '' || $id_ara !== '';
?>

<div class="ust-bar"><div class="ust-bar-baslik">Hasta Listesi</div></div>

<div class="icerik">

    
    <div class="panel" style="margin-bottom:16px;">
        <div class="panel-baslik"><h3>Hasta Ara</h3></div>
        <div class="panel-icerik">
            <form method="GET" action="">

                
                <div style="margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid rgba(255,255,255,0.07);">
                    <label style="font-size:12px; color:#94a3b8; font-weight:500; display:block; margin-bottom:5px;">
                        Hasta ID
                    </label>
                    <div style="display:flex; gap:8px;">
                        <input type="number" name="id_ara" value="<?= temizle($id_ara) ?>"
                               style="width:200px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:7px; padding:9px 12px; color:#f8fafc; font-family:'DM Sans',sans-serif; font-size:13px; outline:none;">
                        <button type="submit" class="btn btn-mavi btn-kucuk">ID ile Ara</button>
                    </div>
                </div>

                
                <div class="form-grid">
                    <div class="form-grup">
                        <label>Ad, Soyad veya TC</label>
                        <input type="text" name="ara" value="<?= temizle($arama) ?>">
                    </div>
                    <div class="form-grup">
                        <label>Cinsiyet</label>
                        <select name="cinsiyet">
                            <option value="">-- Tümü --</option>
                            <option value="Erkek" <?= $cinsiyet === 'Erkek' ? 'selected' : '' ?>>Erkek</option>
                            <option value="Kadın" <?= $cinsiyet === 'Kadın' ? 'selected' : '' ?>>Kadın</option>
                        </select>
                    </div>
                    <div class="form-grup">
                        <label>Kan Grubu</label>
                        <select name="kan">
                            <option value="">-- Tümü --</option>
                            <?php foreach (['A+','A-','B+','B-','AB+','AB-','0+','0-'] as $kg): ?>
                            <option value="<?= $kg ?>" <?= $kan === $kg ? 'selected' : '' ?>><?= $kg ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-grup">
                        <label>Telefon</label>
                        <input type="text" name="tel" value="<?= temizle($tel) ?>">
                    </div>
                    <div class="form-grup">
                        <label>Minimum Yaş</label>
                        <input type="number" name="yas_min" value="<?= temizle($yas_min) ?>" min="0" max="120">
                    </div>
                    <div class="form-grup">
                        <label>Maksimum Yaş</label>
                        <input type="number" name="yas_max" value="<?= temizle($yas_max) ?>" min="0" max="120">
                    </div>
                </div>

                <div class="form-aksiyonlar">
                    <button type="submit" class="btn btn-mavi">Filtrele</button>
                    <?php if ($aramaVar): ?>
                    <a href="hasta_listesi.php" class="btn btn-gri">✕ Temizle</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    
    <?php if ($hasta_detay): ?>
    <div class="panel" style="margin-bottom:20px; border:1px solid rgba(59,130,246,0.3);">
        <div class="panel-baslik">
            <h3>Hasta Detayı — #<?= $hasta_detay['HastaID'] ?></h3>
            <a href="hasta_listesi.php">✕ Kapat</a>
        </div>
        <div class="panel-icerik">
            <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:16px;">
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Ad</div><div><?= temizle($hasta_detay['Ad']) ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Soyad</div><div><?= temizle($hasta_detay['Soyad']) ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">TC Kimlik</div><div><?= temizle($hasta_detay['TCKimlik']) ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Doğum / Yaş</div>
                    <div><?= tarihFormat($hasta_detay['DogumTarihi']) ?>
                        <?php
                        if ($hasta_detay['DogumTarihi']) {
                            $yas = date_diff(date_create(tarihFormat($hasta_detay['DogumTarihi'])), date_create('today'))->y;
                            echo " <span style='color:#64748b;font-size:11px;'>($yas yaş)</span>";
                        }
                        ?>
                    </div>
                </div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Kan Grubu</div><div><span class="etiket etiket-kirmizi"><?= temizle($hasta_detay['KanGrubu'] ?? '-') ?></span></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Cinsiyet</div><div><?= temizle($hasta_detay['Cinsiyet'] ?? '-') ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Telefon</div><div><?= temizle($hasta_detay['Telefon'] ?? '-') ?></div></div>
            </div>

            <div style="font-size:12px;color:#64748b;margin-bottom:8px;font-weight:500;text-transform:uppercase;letter-spacing:0.5px;">Tahlil Durumu</div>
            <table class="tablo" style="margin-bottom:16px;">
                <thead><tr><th>Tür</th><th>Doktor</th><th>İstek</th><th>Sonuç</th><th>Durum</th></tr></thead>
                <tbody>
                <?php $t_sayi=0; while($t = sqlsrv_fetch_array($tahliller, SQLSRV_FETCH_ASSOC)): $t_sayi++; ?>
                <tr>
                    <td><?= temizle($t['TahlilTuru']) ?></td>
                    <td class="soluk">Dr. <?= temizle($t['doktor_adi']) ?></td>
                    <td class="soluk"><?= tarihFormat($t['IstekTarihi']) ?></td>
                    <td class="soluk"><?= $t['Sonuc'] ? temizle(substr($t['Sonuc'],0,40)) : '—' ?></td>
                    <td><span class="etiket <?= $t['Durum']==='Tamamlandı' ? 'etiket-yesil' : 'etiket-sari' ?>"><?= $t['Durum'] ?></span></td>
                </tr>
                <?php endwhile; if($t_sayi===0): ?>
                <tr><td colspan="5" style="color:#64748b;text-align:center;padding:10px;">Tahlil yok</td></tr>
                <?php endif; ?>
                </tbody>
            </table>

            <div style="font-size:12px;color:#64748b;margin-bottom:8px;font-weight:500;text-transform:uppercase;letter-spacing:0.5px;">Randevular</div>
            <table class="tablo">
                <thead><tr><th>Tarih</th><th>Doktor</th><th>Bölüm</th><th>Durum</th></tr></thead>
                <tbody>
                <?php $rv_sayi=0; while($rv = sqlsrv_fetch_array($randevular, SQLSRV_FETCH_ASSOC)): $rv_sayi++; ?>
                <tr>
                    <td class="soluk"><?= tarihFormat($rv['RandevuTarihi'], 'd.m.Y H:i') ?></td>
                    <td>Dr. <?= temizle($rv['doktor_adi']) ?></td>
                    <td class="soluk"><?= temizle($rv['BolumAdi']) ?></td>
                    <td><span class="etiket <?= match($rv['Durum']){'Tamamlandı'=>'etiket-yesil','İptal'=>'etiket-kirmizi',default=>'etiket-sari'} ?>"><?= $rv['Durum'] ?></span></td>
                </tr>
                <?php endwhile; if($rv_sayi===0): ?>
                <tr><td colspan="4" style="color:#64748b;text-align:center;padding:10px;">Randevu yok</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php elseif ($hasta_id_detay): ?>
    <div class="bildirim bildirim-hata">✗ Bu ID ile hasta bulunamadı.</div>
    <?php endif; ?>

    
    <div class="panel">
        <div class="tablo-sarici">
            <table class="tablo">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ad</th>
                        <th>Soyad</th>
                        <th>TC Kimlik</th>
                        <th>Doğum</th>
                        <th>Yaş</th>
                        <th>Cinsiyet</th>
                        <th>Kan Grubu</th>
                        <th>Telefon</th>
                        <th>Detay</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $sonuc_var = false;
                while ($h = sqlsrv_fetch_array($hastalar, SQLSRV_FETCH_ASSOC)):
                    $sonuc_var = true;
                ?>
                <tr>
                    <td><span class="etiket etiket-mavi">#<?= $h['HastaID'] ?></span></td>
                    <td><?= temizle($h['Ad']) ?></td>
                    <td><?= temizle($h['Soyad']) ?></td>
                    <td class="soluk"><?= temizle($h['TCKimlik']) ?></td>
                    <td class="soluk"><?= tarihFormat($h['DogumTarihi']) ?></td>
                    <td class="soluk"><?= $h['yas'] ?? '-' ?></td>
                    <td class="soluk"><?= temizle($h['Cinsiyet'] ?? '-') ?></td>
                    <td><span class="etiket etiket-kirmizi"><?= temizle($h['KanGrubu'] ?? '-') ?></span></td>
                    <td class="soluk"><?= temizle($h['Telefon'] ?? '-') ?></td>
                    <td>
                        <a href="?hasta_id=<?= $h['HastaID'] ?>" class="btn btn-mavi btn-kucuk">Görüntüle</a>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if (!$sonuc_var): ?>
                <tr><td colspan="10" style="text-align:center;color:#64748b;padding:20px;">Sonuç bulunamadı.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once '../includes/footer.php'; ?>