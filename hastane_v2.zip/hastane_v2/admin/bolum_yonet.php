<?php
require_once 'bolum_yonet_islem.php';
require_once 'layout.php';
?>

<div class="ust-bar"><div class="ust-bar-baslik">Bölüm Yönetimi</div></div>

<div class="icerik">

    <?php if ($mesaj): ?>
        <div class="bildirim bildirim-<?= $mesaj['tip']==='basari'?'basari':'hata' ?>">
            <?= $mesaj['tip']==='basari'?'✓':'✗' ?> <?= temizle($mesaj['metin']) ?>
        </div>
    <?php endif; ?>

    <div class="panel" style="max-width:500px; margin-bottom:20px;">
        <div class="panel-baslik"><h3>Yeni Bölüm Ekle</h3></div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <div class="form-grup" style="margin-bottom:12px;">
                    <label>Bölüm Adı *</label>
                    <input type="text" name="bolum_adi" placeholder="ör: Kardiyoloji"
                           value="<?= temizle($_POST['bolum_adi'] ?? '') ?>">
                </div>
                <button type="submit" name="ekle" class="btn btn-mavi">+ Bölüm Ekle</button>
            </form>
        </div>
    </div>

    <div class="sayfa-baslik"><h2>Mevcut Bölümler</h2></div>
    <div class="panel" style="max-width:600px;">
        <div class="tablo-sarici">
            <table class="tablo">
                <thead><tr><th>#</th><th>Bölüm Adı</th><th>Kayıtlı Çalışan</th><th>İşlem</th></tr></thead>
                <tbody>
                <?php while ($b = sqlsrv_fetch_array($bolumler, SQLSRV_FETCH_ASSOC)): ?>
                <tr>
                    <td class="soluk"><?= $b['BolumID'] ?></td>
                    <td><?= temizle($b['BolumAdi']) ?></td>
                    <td><span class="etiket <?= $b['kullanici_sayisi']>0?'etiket-mavi':'etiket-gri' ?>"><?= $b['kullanici_sayisi'] ?> kişi</span></td>
                    <td>
                        <a href="?sil=<?= $b['BolumID'] ?>" class="btn btn-kirmizi btn-kucuk"
                           onclick="return confirm('<?= temizle($b['BolumAdi']) ?> silinsin mi?')">🗑 Sil</a>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once '../includes/footer.php'; ?>