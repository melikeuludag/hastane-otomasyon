<?php
require_once 'kullanici_listesi_islem.php';
require_once 'layout.php';
?>

<div class="ust-bar">
    <div class="ust-bar-baslik">Kullanıcı Listesi</div>
</div>

<div class="icerik">

    <?php if ($mesaj): ?>
        <div class="bildirim bildirim-<?= $mesaj['tip']==='basari'?'basari':'hata' ?>">
            <?= $mesaj['tip']==='basari'?'✓':'✗' ?> <?= temizle($mesaj['metin']) ?>
        </div>
    <?php endif; ?>

    <?php if ($duzenle): ?>
    <div class="panel" style="margin-bottom:20px;border:1px solid rgba(245,158,11,0.3);">
        <div class="panel-baslik">
            <h3>✏️ Kullanıcı Güncelle — <?= temizle($duzenle['Ad'].' '.$duzenle['Soyad']) ?></h3>
            <a href="kullanici_listesi.php">✕ İptal</a>
        </div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <input type="hidden" name="kullanici_id" value="<?= $duzenle['KullaniciID'] ?>">
                <div class="form-grid">
                    <div class="form-grup">
                        <label>TC Kimlik (değiştirilemez)</label>
                        <input type="text" value="<?= temizle($duzenle['TCKimlik']) ?>" disabled style="opacity:0.5;cursor:not-allowed;">
                    </div>
                    <div class="form-grup">
                        <label>Telefon</label>
                        <input type="text" name="telefon" value="<?= temizle($duzenle['Telefon'] ?? '') ?>">
                    </div>
                    <div class="form-grup">
                        <label>Ad *</label>
                        <input type="text" name="ad" value="<?= temizle($_POST['ad'] ?? $duzenle['Ad']) ?>">
                    </div>
                    <div class="form-grup">
                        <label>Soyad *</label>
                        <input type="text" name="soyad" value="<?= temizle($_POST['soyad'] ?? $duzenle['Soyad']) ?>">
                    </div>
                    <div class="form-grup">
                        <label>Yeni Şifre <span style="color:#64748b">(boş = değişmez)</span></label>
                        <input type="text" name="sifre" placeholder="Yeni şifre...">
                    </div>
                    <div class="form-grup">
                        <label>Unvan</label>
                        <select name="unvan">
                            <option value="admin"    <?= $duzenle['Unvan']==='admin'   ?'selected':'' ?>>Admin</option>
                            <option value="doktor"   <?= $duzenle['Unvan']==='doktor'  ?'selected':'' ?>>Doktor</option>
                            <option value="sekreter" <?= $duzenle['Unvan']==='sekreter'?'selected':'' ?>>Sekreter</option>
                        </select>
                    </div>
                    <div class="form-grup">
                        <label>Bölüm</label>
                        <select name="bolum_id">
                            <option value="">-- Seçin --</option>
                            <?php foreach ($bolum_listesi as $b): ?>
                            <option value="<?= $b['BolumID'] ?>" <?= $duzenle['BolumID']==$b['BolumID']?'selected':'' ?>>
                                <?= temizle($b['BolumAdi']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-aksiyonlar">
                    <button type="submit" name="guncelle" class="btn btn-mavi">💾 Güncelle</button>
                    <a href="kullanici_listesi.php" class="btn btn-gri">İptal</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="sayfa-baslik">
        <h2>Tüm Kullanıcılar</h2>
        <a href="kullanici_ekle.php" class="btn btn-mavi">+ Yeni Kullanıcı</a>
    </div>

    <div class="panel">
        <div class="tablo-sarici">
            <table class="tablo">
                <thead>
                    <tr><th>#</th><th>Ad</th><th>Soyad</th><th>TC Kimlik</th><th>Unvan</th><th>Bölüm</th><th>Telefon</th><th>İşlemler</th></tr>
                </thead>
                <tbody>
                <?php while ($k = sqlsrv_fetch_array($kullanicilar, SQLSRV_FETCH_ASSOC)):
                    $renk = match($k['Unvan']) { 'admin'=>'etiket-kirmizi','doktor'=>'etiket-mavi','sekreter'=>'etiket-yesil',default=>'etiket-gri' };
                    $unvan_adi = match($k['Unvan']) { 'admin'=>'Admin','doktor'=>'Doktor','sekreter'=>'Sekreter',default=>$k['Unvan'] };
                ?>
                <tr>
                    <td class="soluk"><?= $k['KullaniciID'] ?></td>
                    <td><?= temizle($k['Ad']) ?></td>
                    <td><?= temizle($k['Soyad']) ?></td>
                    <td class="soluk"><?= temizle($k['TCKimlik']) ?></td>
                    <td><span class="etiket <?= $renk ?>"><?= $unvan_adi ?></span></td>
                    <td class="soluk"><?= temizle($k['BolumAdi'] ?? '-') ?></td>
                    <td class="soluk"><?= temizle($k['Telefon'] ?? '-') ?></td>
                    <td>
                        <a href="?duzenle=<?= $k['KullaniciID'] ?>" class="btn btn-gri btn-kucuk">✏️ Düzenle</a>
                        <?php if ($k['KullaniciID'] !== (int)$_SESSION['kullanici_id']): ?>
                        <a href="?sil=<?= $k['KullaniciID'] ?>" class="btn btn-kirmizi btn-kucuk"
                           onclick="return confirm('<?= temizle($k['Ad'].' '.$k['Soyad']) ?> silinsin mi?')">🗑 Sil</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once '../includes/footer.php'; ?>