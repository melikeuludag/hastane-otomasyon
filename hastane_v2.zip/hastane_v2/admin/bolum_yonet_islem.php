<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$mesaj = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ekle'])) {
    $bolum_adi = trim($_POST['bolum_adi'] ?? '');
    if (empty($bolum_adi)) {
        $mesaj = ['tip'=>'hata', 'metin'=>'Bölüm adı boş bırakılamaz.'];
    } else {
        $sorgu = sqlsrv_query($conn, "INSERT INTO Bolumler (BolumAdi) VALUES (?)", [$bolum_adi]);
        $mesaj = $sorgu
            ? ['tip'=>'basari', 'metin'=>"\"$bolum_adi\" bölümü eklendi."]
            : ['tip'=>'hata',   'metin'=>'Hata oluştu.'];
        $_POST = [];
    }
}

if (isset($_GET['sil'])) {
    $sil_id  = (int)$_GET['sil'];
    $kontrol = sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Kullanicilar WHERE BolumID=?", [$sil_id]);
    $sayi    = sqlsrv_fetch_array($kontrol)['c'];
    if ($sayi > 0) {
        $mesaj = ['tip'=>'hata', 'metin'=>'Bu bölümde kayıtlı kullanıcı var. Önce kullanıcıları taşı.'];
    } else {
        sqlsrv_query($conn, "DELETE FROM Bolumler WHERE BolumID=?", [$sil_id]);
        header("Location: bolum_yonet.php?silindi=1"); exit;
    }
}
if (isset($_GET['silindi'])) $mesaj = ['tip'=>'basari', 'metin'=>'Bölüm silindi.'];

$bolumler = sqlsrv_query($conn, "
    SELECT B.BolumID, B.BolumAdi, COUNT(K.KullaniciID) as kullanici_sayisi
    FROM Bolumler B
    LEFT JOIN Kullanicilar K ON B.BolumID = K.BolumID
    GROUP BY B.BolumID, B.BolumAdi
    ORDER BY B.BolumAdi
");
?>