<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap - Hastane Takip Sistemi</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500&family=Syne:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/hastane_v2/assets/css/login.css">
</head>
<body>

<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$hata = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tc    = trim($_POST['tc_kimlik'] ?? '');
    $sifre = trim($_POST['sifre']     ?? '');

    if (empty($tc) || empty($sifre)) {
        $hata = 'TC kimlik ve şifre boş bırakılamaz.';
    } elseif (!tcDogrula($tc)) {
        $hata = 'Geçerli bir TC kimlik numarası girin (11 hane, 0 ile başlamamalı).';
    } else {
        $sql   = "SELECT * FROM Kullanicilar WHERE TCKimlik = ? AND aktif = 1";
        $sorgu = sqlsrv_query($conn, $sql, [$tc]);
        $kullanici = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);

        if ($kullanici && $kullanici['Sifre'] === $sifre) {
            $_SESSION['kullanici_id'] = $kullanici['KullaniciID'];
            $_SESSION['ad_soyad']     = $kullanici['Ad'] . ' ' . $kullanici['Soyad'];
            $_SESSION['tc_kimlik']    = $kullanici['TCKimlik'];
            $_SESSION['unvan']        = $kullanici['Unvan'];
            $_SESSION['bolum_id']     = $kullanici['BolumID'];

            switch ($kullanici['Unvan']) {
                case 'admin':
                    header("Location: /hastane_v2/admin/index.php"); break;
                case 'doktor':
                    header("Location: /hastane_v2/doktor/index.php"); break;
                case 'sekreter':
                    header("Location: /hastane_v2/sekreter/index.php"); break;
            }
            exit;
        } else {
            $hata = 'TC kimlik veya şifre hatalı.';
        }
    }
}
?>

<div class="giris-kutu">
    <div class="giris-logo">
        <div class="ikon">🏥</div>
        <h1>Hastane Takip Sistemi</h1>
        <p>Devam etmek için giriş yapın</p>
    </div>

    <?php if ($hata): ?>
        <div class="hata-mesaj"><?= temizle($hata) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="form-grup">
            <label for="tc">TC Kimlik No</label>
            <input type="text" id="tc" name="tc_kimlik" maxlength="11"
                   value="<?= temizle($_POST['tc_kimlik'] ?? '') ?>"
                   autocomplete="off" required>
        </div>
        <div class="form-grup">
            <label for="sifre">Şifre</label>
            <input type="password" id="sifre" name="sifre">
        </div>
        <button type="submit" class="giris-btn">Giriş Yap</button>
    </form>
</div>

</body>
</html>