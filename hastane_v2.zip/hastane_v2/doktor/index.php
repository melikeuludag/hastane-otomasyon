<?php
require_once '../includes/db.php';
require_once 'layout.php';
$doktor_id = $_SESSION['kullanici_id'];
$bugun_randevu   = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Randevular WHERE DoktorID=? AND CAST(RandevuTarihi AS DATE)=CAST(GETDATE() AS DATE)", [$doktor_id]))['c'];
$bekleyen        = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Randevular WHERE DoktorID=? AND Durum='Bekliyor'", [$doktor_id]))['c'];
$tahlil_bekleyen = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Tahliller WHERE DoktorID=? AND Durum='Bekliyor'", [$doktor_id]))['c'];
$randevular = sqlsrv_query($conn, "
    SELECT TOP 8 R.RandevuTarihi, R.Durum, H.Ad, H.Soyad
    FROM Randevular R JOIN Hastalar H ON R.HastaID=H.HastaID
    WHERE R.DoktorID=? AND CAST(R.RandevuTarihi AS DATE)=CAST(GETDATE() AS DATE)
    ORDER BY R.RandevuTarihi ASC
", [$doktor_id]);
?>
<div class="ust-bar">
    <div class="ust-bar-baslik">Hoşgeldiniz, Dr. <?= temizle($_SESSION['ad_soyad']) ?></div>
    <div class="ust-bar-sag"><span class="etiket etiket-mavi"><?= date('d.m.Y') ?></span></div>
</div>
<div class="icerik">
    <div class="stat-grid stat-grid-3">
        <div class="stat-kart mavi"><div class="stat-etiket">Bugünkü Randevu</div><div class="stat-deger"><?= $bugun_randevu ?></div></div>
        <div class="stat-kart sari"><div class="stat-etiket">Bekleyen Randevu</div><div class="stat-deger"><?= $bekleyen ?></div></div>
        <div class="stat-kart kirmizi"><div class="stat-etiket">Bekleyen Tahlil</div><div class="stat-deger"><?= $tahlil_bekleyen ?></div></div>
    </div>
    <div class="panel">
        <div class="panel-baslik"><h3>Bugünkü Randevularım</h3><a href="/hastane_v2/doktor/randevular.php">Tümünü Gör →</a></div>
        <?php $sayi=0; while($r=sqlsrv_fetch_array($randevular,SQLSRV_FETCH_ASSOC)): $sayi++;
            $renk=match($r['Durum']){'Tamamlandı'=>'#10b981','İptal'=>'#ef4444',default=>'#3b82f6'}; ?>
        <div class="randevu-satir">
            <span class="randevu-saat"><?= saatFormat($r['RandevuTarihi']) ?></span>
            <span class="randevu-nokta" style="background:<?= $renk ?>"></span>
            <span class="randevu-hasta"><?= temizle($r['Ad'].' '.$r['Soyad']) ?></span>
        </div>
        <?php endwhile; if($sayi===0): ?>
        <div style="padding:20px;text-align:center;color:#64748b;font-size:13px;">Bugün randevunuz bulunmuyor.</div>
        <?php endif; ?>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>