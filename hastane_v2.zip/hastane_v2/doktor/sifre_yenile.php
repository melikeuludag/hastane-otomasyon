<?php
require_once '../includes/db.php';
require_once 'layout.php';
$kullanici_id = $_SESSION['kullanici_id'];
$mesaj        = null;
$hatalar      = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mevcut = trim($_POST['mevcut_sifre'] ?? '');
    $yeni   = trim($_POST['yeni_sifre']   ?? '');
    $tekrar = trim($_POST['tekrar_sifre'] ?? '');

    $sorgu = sqlsrv_query($conn, "SELECT Sifre FROM Kullanicilar WHERE KullaniciID=?", [$kullanici_id]);
    $k     = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);

    if ($k['Sifre'] !== $mevcut) $hatalar['mevcut'] = 'Mevcut şifre hatalı.';
    if (strlen($yeni) < 4)       $hatalar['yeni']   = 'Yeni şifre en az 4 karakter olmalı.';
    if ($yeni !== $tekrar)       $hatalar['tekrar'] = 'Şifreler eşleşmiyor.';

    if (empty($hatalar)) {
        sqlsrv_query($conn, "UPDATE Kullanicilar SET Sifre=? WHERE KullaniciID=?", [$yeni, $kullanici_id]);
        $mesaj = ['tip'=>'basari','metin'=>'Şifreniz başarıyla güncellendi.'];
        $_POST = [];
    }
}
?>

<div class="ust-bar"><div class="ust-bar-baslik">Şifre Yenile</div></div>
<div class="icerik">

    <?php if ($mesaj): ?><div class="bildirim bildirim-basari">✓ <?= temizle($mesaj['metin']) ?></div><?php endif; ?>

    <div class="panel" style="max-width:450px;">
        <div class="panel-baslik"><h3>Şifre Değiştir</h3></div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <div class="form-grup" style="margin-bottom:14px;">
                    <label>Mevcut Şifre *</label>
                    <input type="password" name="mevcut_sifre" placeholder="Mevcut şifreniz"
                           class="<?= isset($hatalar['mevcut'])?'hatali':'' ?>">
                    <?php if (isset($hatalar['mevcut'])): ?><span class="form-hata"><?= $hatalar['mevcut'] ?></span><?php endif; ?>
                </div>
                <div class="form-grup" style="margin-bottom:14px;">
                    <label>Yeni Şifre *</label>
                    <input type="password" name="yeni_sifre" placeholder="En az 4 karakter"
                           class="<?= isset($hatalar['yeni'])?'hatali':'' ?>">
                    <?php if (isset($hatalar['yeni'])): ?><span class="form-hata"><?= $hatalar['yeni'] ?></span><?php endif; ?>
                </div>
                <div class="form-grup" style="margin-bottom:18px;">
                    <label>Yeni Şifre (Tekrar) *</label>
                    <input type="password" name="tekrar_sifre" placeholder="Şifreyi tekrar girin"
                           class="<?= isset($hatalar['tekrar'])?'hatali':'' ?>">
                    <?php if (isset($hatalar['tekrar'])): ?><span class="form-hata"><?= $hatalar['tekrar'] ?></span><?php endif; ?>
                </div>
                <button type="submit" class="btn btn-mavi">🔒 Şifremi Güncelle</button>
            </form>
        </div>
    </div>

</div>
<?php require_once '../includes/footer.php'; ?>