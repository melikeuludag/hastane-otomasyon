<?php
require_once __DIR__ . '/../includes/functions.php';
girisKontrol();
rolKontrol(['doktor']);
$aktif_sayfa = basename($_SERVER['PHP_SELF']);
$doktor_id   = $_SESSION['kullanici_id'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doktor Paneli - Hastane Takip</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500&family=Syne:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/hastane_v2/assets/css/style.css">
</head>
<body>
<div class="sayfa-yapisi">
<div class="sidebar">
    <div class="sidebar-logo">
        <div class="ikon">👨‍⚕️</div>
        <h2>Doktor Paneli</h2>
        <span>Hastane Takip Sistemi</span>
    </div>
    <div class="menu-grup">
        <div class="menu-baslik">Menü</div>
        <a href="/hastane_v2/doktor/index.php" class="menu-link <?= $aktif_sayfa==='index.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="currentColor"><rect x="1" y="1" width="6" height="6" rx="1"/><rect x="9" y="1" width="6" height="6" rx="1"/><rect x="1" y="9" width="6" height="6" rx="1"/><rect x="9" y="9" width="6" height="6" rx="1"/></svg>
            Gösterge
        </a>
        <a href="/hastane_v2/doktor/randevular.php" class="menu-link <?= $aktif_sayfa==='randevular.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="2" y="3" width="12" height="11" rx="1"/><path d="M5 1v4M11 1v4M2 7h12"/></svg>
            Randevularım
        </a>
        <a href="/hastane_v2/doktor/hastalar.php" class="menu-link <?= $aktif_sayfa==='hastalar.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="5" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6"/></svg>
            Hastalarım
        </a>
        <a href="/hastane_v2/doktor/muayene_yaz.php" class="menu-link <?= $aktif_sayfa==='muayene_yaz.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="3" y="1" width="10" height="14" rx="1"/><path d="M6 5h4M6 8h4M6 11h2"/></svg>
            Muayene Yaz
        </a>
        <a href="/hastane_v2/doktor/tahlil_iste.php" class="menu-link <?= $aktif_sayfa==='tahlil_iste.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M6 1v6L3 13h10L10 7V1"/><path d="M5 1h6"/></svg>
            Tahlil İste
        </a>
        <a href="/hastane_v2/doktor/sifre_yenile.php" class="menu-link <?= $aktif_sayfa==='sifre_yenile.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="3" y="7" width="10" height="8" rx="1"/><path d="M5 7V5a3 3 0 016 0v2"/></svg>
            Şifre Yenile
        </a>
    </div>
    <div class="sidebar-alt">
        <div class="kullanici-bilgi">
            <strong>Dr. <?= temizle($_SESSION['ad_soyad']) ?></strong><br>
            TC: <?= temizle($_SESSION['tc_kimlik']) ?><br>
            Doktor
        </div>
        <a href="/hastane_v2/logout.php" class="cikis-link">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" width="15" height="15"><path d="M6 2H2v12h4M11 11l3-3-3-3M14 8H6"/></svg>
            Çıkış Yap
        </a>
    </div>
</div>
<div class="ana-icerik">