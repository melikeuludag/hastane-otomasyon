<?php
require_once '../includes/db.php';
require_once 'layout.php';
$doktor_id = $_SESSION['kullanici_id'];
$mesaj     = null;

$tahlil_turleri = [
    'Tam Kan Sayımı','Biyokimya','İdrar Tahlili','EKG',
    'Akciğer Röntgeni','Beyin MRI','Diz Röntgeni','Ultrason',
    'Tiroit Testi (TSH)','HbA1c (Şeker)','Kolesterol','Diğer'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hasta_id    = (int)$_POST['hasta_id'];
    $tahlil_turu = trim($_POST['tahlil_turu'] ?? '');
    $diger       = trim($_POST['tahlil_diger'] ?? '');
    if ($tahlil_turu === 'Diğer' && !empty($diger)) $tahlil_turu = $diger;

    if (!$hasta_id || empty($tahlil_turu)) {
        $mesaj = ['tip'=>'hata','metin'=>'Hasta ve tahlil türü seçilmeli.'];
    } else {
        $sorgu = sqlsrv_query($conn,
            "INSERT INTO Tahliller (HastaID, DoktorID, TahlilTuru, Durum) VALUES (?, ?, ?, 'Bekliyor')",
            [$hasta_id, $doktor_id, $tahlil_turu]
        );
        $mesaj = $sorgu
            ? ['tip'=>'basari','metin'=>"\"$tahlil_turu\" tahlili istendi."]
            : ['tip'=>'hata',  'metin'=>'Hata oluştu.'];
        if ($sorgu) $_POST = [];
    }
}

// Bu doktorun hastaları
$hastalar = sqlsrv_query($conn, "
    SELECT DISTINCT H.HastaID, H.Ad, H.Soyad
    FROM Hastalar H JOIN Randevular R ON H.HastaID=R.HastaID
    WHERE R.DoktorID=? ORDER BY H.Ad
", [$doktor_id]);
$hasta_listesi = [];
while ($h = sqlsrv_fetch_array($hastalar, SQLSRV_FETCH_ASSOC)) $hasta_listesi[] = $h;

// Tahlil geçmişi
$tahlil_gecmis = sqlsrv_query($conn, "
    SELECT T.TahlilID, T.TahlilTuru, T.IstekTarihi, T.Sonuc, T.Durum,
           H.Ad, H.Soyad
    FROM Tahliller T JOIN Hastalar H ON T.HastaID=H.HastaID
    WHERE T.DoktorID=? ORDER BY T.IstekTarihi DESC
", [$doktor_id]);
?>

<div class="ust-bar"><div class="ust-bar-baslik">Tahlil İste</div></div>
<div class="icerik">

    <?php if ($mesaj): ?>
        <div class="bildirim bildirim-<?= $mesaj['tip']==='basari'?'basari':'hata' ?>">
            <?= $mesaj['tip']==='basari'?'✓':'✗' ?> <?= temizle($mesaj['metin']) ?>
        </div>
    <?php endif; ?>

    <div class="panel" style="max-width:600px;margin-bottom:24px;">
        <div class="panel-baslik"><h3>Yeni Tahlil İste</h3></div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-grup">
                        <label>Hasta *</label>
                        <select name="hasta_id" required>
                            <option value="">-- Hasta Seç --</option>
                            <?php foreach ($hasta_listesi as $h): ?>
                            <option value="<?= $h['HastaID'] ?>" <?= ($_POST['hasta_id']??'')==$h['HastaID']?'selected':'' ?>>
                                #<?= $h['HastaID'] ?> — <?= temizle($h['Ad'].' '.$h['Soyad']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-grup">
                        <label>Tahlil Türü *</label>
                        <select name="tahlil_turu" required onchange="digerKontrol(this)">
                            <option value="">-- Seç --</option>
                            <?php foreach ($tahlil_turleri as $tur): ?>
                            <option value="<?= $tur ?>" <?= ($_POST['tahlil_turu']??'')===$tur?'selected':'' ?>><?= $tur ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-grup tam" id="diger_alan" style="display:none;">
                        <label>Tahlil Adını Girin</label>
                        <input type="text" name="tahlil_diger" placeholder="Tahlil adını yazın..." value="<?= temizle($_POST['tahlil_diger']??'') ?>">
                    </div>
                </div>
                <div class="form-aksiyonlar">
                    <button type="submit" class="btn btn-mavi">+ Tahlil İste</button>
                </div>
            </form>
        </div>
    </div>

    <div class="sayfa-baslik"><h2>Tahlil Geçmişim</h2></div>
    <div class="panel"><div class="tablo-sarici">
        <table class="tablo">
            <thead><tr><th>#</th><th>Ad</th><th>Soyad</th><th>Tahlil Türü</th><th>İstek Tarihi</th><th>Sonuç</th><th>Durum</th></tr></thead>
            <tbody>
            <?php while($t=sqlsrv_fetch_array($tahlil_gecmis,SQLSRV_FETCH_ASSOC)):
                $renk=$t['Durum']==='Tamamlandı'?'etiket-yesil':'etiket-sari'; ?>
            <tr>
                <td class="soluk"><?= $t['TahlilID'] ?></td>
                <td><?= temizle($t['Ad']) ?></td>
                <td><?= temizle($t['Soyad']) ?></td>
                <td><?= temizle($t['TahlilTuru']) ?></td>
                <td class="soluk"><?= tarihFormat($t['IstekTarihi']) ?></td>
                <td class="soluk"><?= $t['Sonuc']?temizle(substr($t['Sonuc'],0,50)).'...':'—' ?></td>
                <td><span class="etiket <?= $renk ?>"><?= temizle($t['Durum']) ?></span></td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div></div>

</div>

<script>
function digerKontrol(sel) {
    document.getElementById('diger_alan').style.display = sel.value==='Diğer' ? 'flex' : 'none';
}
window.onload = function() {
    var sel = document.getElementById('tahlil_turu');
    if (sel) digerKontrol(sel);
};
</script>

<?php require_once '../includes/footer.php'; ?>